package com.company.chatSystem;

/**
 * Created by User on 22/11/2014.
 */
public interface StringConsumer {
    public void consume(String str) ;
}
