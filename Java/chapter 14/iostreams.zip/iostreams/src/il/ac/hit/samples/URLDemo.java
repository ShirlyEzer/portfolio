package il.ac.hit.samples;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class URLDemo {

	public static void main(String[] args) {
		InputStream in = null;
		URL url = null;
		try {
			url = new URL("http://www.lifemichael.com/index.html");
			in = url.openStream();
			int tmp = in.read();
			while (tmp != -1) {
				System.out.print((char) tmp);
				tmp = in.read();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}
}
