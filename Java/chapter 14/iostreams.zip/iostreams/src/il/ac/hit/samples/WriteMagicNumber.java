package il.ac.hit.samples;

import java.io.*;

public class WriteMagicNumber {
	private static String fileName = "magic";
	
	public static void main(String[] args) {
		FileOutputStream fos = null;
		DataOutputStream dos = null;
		try
		{
			int number = Integer.parseInt(args[0]);
			fos = new FileOutputStream(fileName);
			dos = new DataOutputStream(fos);
			dos.writeInt(number);
			dos.flush();
		}
		catch(IOException e)
		{
			e.printStackTrace();
			
		}
		finally
		{
			if(fos!=null) {
				try {
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(dos!=null) {
				try {
					dos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
