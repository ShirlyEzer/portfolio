package il.ac.hit.samples;

import java.io.*;

public class ReadStudent {

	public static void main(String[] args) {
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		try
		{
			fis = new FileInputStream(args[0]);
			ois = new ObjectInputStream(fis);
			Object ob = ois.readObject();
			
		}
		catch(IOException | ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		
		{
			if(fis!=null)
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if(ois!=null)
				try {
					ois.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}

}
