package il.ac.hit.samples;

import java.io.File;

public class FileDemo {

	public static void main(String[] args) {
		File file = new File("c:\\");
		String[] names = file.list();
		for(String name : names ) {
			System.out.println(name);
		}

	}

}
