package il.ac.hit.samples;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class ReadMagicNumber {
	
	private static String fileName = "magic";

	public static void main(String[] args) {
		FileInputStream fis = null;
		DataInputStream dis = null;
		try
		{

			fis = new FileInputStream(fileName);
			dis = new DataInputStream(fis);
			System.out.println(dis.readInt());
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
			
		}
		finally
		{
			if(fis!=null) {
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(dis!=null) {
				try {
					dis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

}
