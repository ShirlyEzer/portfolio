package il.ac.hit.samples;

import java.io.*;

public class SaveStudent {

	public static void main(String[] args) {
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		try {

			int id = Integer.parseInt(args[0]);
			String name = args[1];
			double average = Double.parseDouble(args[2]);
			Student ob = new Student(id, name, average);
			fos = new FileOutputStream(String.valueOf(id));
			oos = new ObjectOutputStream(fos);
			oos.writeObject(ob);

		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			if(fos!=null)
				try {
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if(oos!=null)
				try {
					oos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

}
