﻿using System;
using System.Collections.Generic;
using System.Text;

namespace B14_Ex02
{
    public class Program
    {
        public static void Main()
        {
            GameInterface newMemoryGame = new GameInterface();
            newMemoryGame.StartGame();
        }  
    }
}
