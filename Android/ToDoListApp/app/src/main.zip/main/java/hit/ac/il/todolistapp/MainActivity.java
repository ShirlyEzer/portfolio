package hit.ac.il.todolistapp;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends Activity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = (WebView) findViewById(R.id.webView);
        webView.loadUrl("http://192.168.43.11/doitsimple/homepage");
        webView.getSettings().setJavaScriptEnabled(true);
        //AlarmSender alarmSender = new AlarmSender();
        //webView.addJavascriptInterface(alarmSender,"alarmSenderProp");
        webView.setWebViewClient(new UrlInterceptor());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        if (intent != null) {
            String time = intent.getStringExtra("time");
            System.out.print(time);
            String name = intent.getStringExtra("name");
            System.out.print(name);
            String description = intent.getStringExtra("description");
            System.out.print(description);
            //load the url for the specific item
            webView.loadUrl("http://192.168.43.11/doitsimple/todo_item_manager");
        }
    }

    class AlarmSender {

        @android.webkit.JavascriptInterface
        public void addAlarmPerToDoItem(String name, String description, String time) {
            //explicit intent
            Intent intent = new Intent(MainActivity.this, NotificationService.class);
            intent.putExtra("name", name);
            intent.putExtra("description", description);
            intent.putExtra("time", time);
            PendingIntent pendingIntent = PendingIntent.getService(MainActivity.this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, ParseDateToTimeStamp(time), pendingIntent);
        }

        public Long ParseDateToTimeStamp(String dueDate) {
            Date date = null;
            DateFormat simpleDate = new SimpleDateFormat("dd-MM-yyyy hh:mm");
            try {
                date = simpleDate.parse(dueDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            java.sql.Timestamp timeStampDate = new Timestamp(date.getTime());
            System.out.println(timeStampDate);
            System.out.println(timeStampDate.getTime());
            return timeStampDate.getTime();
        }
    }
}