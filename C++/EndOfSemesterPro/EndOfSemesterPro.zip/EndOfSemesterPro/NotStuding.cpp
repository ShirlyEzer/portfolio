#include <iostream>
#include "NotStuding.h"
NotStuding :: NotStuding():Student()
{
}
NotStuding :: ~NotStuding()
{
}
void NotStuding::PassDegree()
{
	cout<<"You dont study to any Degree\n";
}